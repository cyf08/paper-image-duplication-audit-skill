# Review Rules

## Evidence Levels

- `high`: localized candidate score is at least `0.90`, both evidence patches pass minimum size filters, and the highlighted regions show the same internal band/blob structure after contrast normalization.
- `medium`: score is `0.82-0.899` or the visual match is plausible but affected by low contrast, compression, small patch size, or weak surrounding context.
- `low`: score is below `0.82`; use only for exploratory follow-up, not as a reportable concern without additional evidence.

## Western Blot / Gel Checks

Compare only blot-like panels with blot-like panels. Prefer local band-patch candidates over whole-panel similarity because scientific blots often reuse a single lane or band rather than the full panel. Treat same-protein-row matching as the default review boundary; cross-protein similarities are usually exploratory false-positive material unless there is independent evidence of relabeling.

Use evidence aggregates as the second-stage WB review layer. An aggregate should be treated as stronger row-level support only when it contains multiple independent one-to-one local matches, consistent lane offset, consistent orientation, and adequate surrounding-context score. Do not describe an aggregate as a whole-row duplicate unless the full-row diagnostic score and visual row context also support that stronger claim.

When reviewing a candidate:

1. Confirm both highlighted boxes sit inside blot/gel image content, not labels, legends, axes, or captions.
2. Confirm both evidence patches are large enough to contain real band structure. Treat tiny isolated blobs as low-confidence even when correlation is high.
3. Compare the band shape, speckle pattern, lane boundary, local background, and compression artifacts.
4. Confirm the reported protein-row labels match the highlighted regions. If one row label was propagated from another panel, inspect the panel image and OCR overlay.
5. Check whether the candidate appears in different panels, conditions, lanes, or experimental contexts.
6. Report the figure/panel pair, protein row, page, score, context score, evidence area, and candidate image path.
7. For aggregate evidence, report the independent support count, raw pairwise count, mean-top score, mean context score, dominant orientation, lane-offset consistency, full-row diagnostic score, and aggregate review image.
8. Use cautious wording: "suspicious reuse candidate" or "requires manual review."

## Multimodal Verification

Use multimodal verification only as a second-stage reviewer of aggregate evidence images. It can help check whether highlighted boxes visually sit on comparable blot bands and whether the aggregate image supports localized reuse, but it must not replace numerical scoring, OCR/protein-row checks, or human review of the manuscript context. The review can be performed by Codex, OpenClaw, or any other agent/tool that can call a vision-capable model; the audit script only needs to provide the evidence image, metadata, prompt, and result schema.

Keep multimodal verification local to the current agent/session for confidential manuscripts unless sending images to an external or hosted model is approved. When a review is available, record the model or agent name, status, confidence, and rationale in the report; treat `uncertain`, tool errors, or missing review results as non-confirmatory rather than negative evidence.

## Common False Positives

- Repeated text labels such as cell-line names or molecular weight markers.
- Smooth background windows with little biological signal.
- Tiny dark blobs or single-band fragments that become artificially similar after resizing.
- Reused chart axes, legends, and plot markers.
- Different lanes with simple, low-information bands.
- Cross-combinations of many similar simple bands within the same protein row. These may create many raw pairwise matches but should not become aggregate findings unless independent one-to-one matches share lane offset, orientation, and context support.
- Images derived from the same control where reuse is disclosed in the caption or methods.

## Reporting Template

Use this compact format:

```text
Finding: Suspicious WB band reuse candidate
Location: Figure <n><panel-a> vs Figure <n><panel-b>, page <page>
Score: <score>, orientation: <orientation>
Context: <context-score>, evidence area: <area-a> px vs <area-b> px
Protein row: <row-label-a> vs <row-label-b>
Evidence: <review image path>
Interpretation: The highlighted blot patches show similar local band/background structure and should be manually checked against the manuscript context.
```
